#!/bin/bash

out/basic -f out/wasm-apps/testapp.wasm