WASM application management
=======

## structure





<img src="../../doc/pics/wamr-arch.JPG" width="80%">
